# Hanos — Planet X and SPHEREx

Team Hanos’s presentation landing page for the 2026 NASA Space Apps Challenge. It retains the supplied Hanos logo and monochrome paper style. All space illustrations and their raster/SVG assets have been removed from the site.

## Open locally

Open `dist/index.html` directly in a browser. No dependencies or build step are required. To serve it instead:

```sh
python3 -m http.server 8080 --directory dist
```

## Page and interactions

The hero, scroll story, project space, resources, and footer share a continuous paper background with no horizontal section boundary. The scroll story uses typography rather than images: 102 infrared wavelengths, approximately six months between full-sky maps, and X as an open question. The numbers are mission context, not a report of team results.

The pinned stage responds to native scrolling; chapter links and a progress line track the story. A shorter sticky stage fits above the text on mobile. The mobile menu supports Escape and focus return. Reduced-motion preferences remove movement, smooth scrolling, and scene fades. Passive scrolling never changes keyboard focus.

The team project name, solution, demo link, repository, and results remain intentionally blank, as requested. Add these in the empty `data-project-blank` container in `dist/index.html` when ready. There are no fabricated project capabilities, member names, results, or discovery claims.

## Content and assets

The challenge summary and mission context are grounded in official Space Apps, NASA/JPL, and NASA/IPAC IRSA sources linked from the page; see `SOURCES.md`. The direct challenge page returned an error in the research tool, so the exact challenge summary was checked on official Space Apps team pages. Full detailed challenge requirements were not independently verified.

The only image in the page is Hanos’s supplied logo. Fira Sans and DejaVu supporting fonts are self-hosted; licenses are in `dist/assets/licenses`. The paper grain is a small SVG noise filter embedded in CSS.

## Verification and publication

JavaScript behavior checks cover mobile navigation, Escape, native anchors, chapter changes, reverse scrolling, resize, progress, and reduced motion. Source checks cover asset paths, anchor targets, removal of the legacy illustrated content, and the intentionally blank project section.

Browser rendering remains unverified in this environment: the sandbox previously blocked browser startup and local sockets. Publication remains incomplete because the required source Git host cannot resolve from this environment. The existing Site identity is retained in `.openai/hosting.json` for a later publication attempt.
